Item ID: 262314
Title: Template - Meeting notes
\uD83D\uDDD3 Date\uD83D\uDC65 Participants\uD83E\uDD45 Goals\uD83D\uDDE3 Discussion topicsTimeItemPresenterNotes✅ Action items ⤴ Decisions
