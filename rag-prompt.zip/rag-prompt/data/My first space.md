Item ID: 262245
Title: My first space





Welcome to your team space!We've added some suggestions and placeholders. Everything is customizable.Get started with page templates:Template - Project planTemplate - Meeting notesTemplate - Weekly status reportCheck out Get the most out of your team space for more tips.
AboutWhat is your team all about?Mission and visionWhat is your team's mission? What is your vision?Meet the teamAdd team members to your space.





Team memberRoleResponsibility



Team memberRoleResponsibility



Team memberRoleResponsibility











Contact usHow can someone reach out to your team?team@email.comTicketsJira board#channel



Important PagesList them here











Onboarding FAQsAdd resources for new hires



Meeting notesAdd links to meeting notes



Team goalsList them here





Team newsCreate a blog post to share team news. It will automatically appear here once it's published.

Blog stream
Create a blog post to share news and announcements with your team and company.
Create blog post





