Item ID: 262300
Title: Template - Project plan
DriverApproverContributorsInformedObjectiveDue dateKey outcomesStatusNOT STARTED / IN PROGRESS / COMPLETE\uD83E\uDD14 Problem Statement🎯 ScopeMust have:Nice to have:Not in scope:\uD83D\uDDD3 Timeline


Oct2021NovDecJan2022FebMarAprMayJun
Lane 1Lane 2Feature 1Feature 2Feature 3Feature 4iOS appAndroid app

\uD83D\uDEA9 Milestones and deadlinesMilestoneOwnerDeadlineStatus\uD83D\uDD17 Reference materials
