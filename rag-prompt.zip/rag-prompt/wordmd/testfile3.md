The tiger story is a short story about a tiger and a small woodpecker bird that lived long ago in the forest. As with most short stories the tiger story has a moral message for kids. Short stories like the one mentioned in the article help kids to have a chance to participate in a fun activity. Apart from it will also help kids to develop and understand the importance of moral virtues in a fun way. Here we attempt to provide a short and precise version of the tiger story. 

The Tiger and the Woodpecker Story

Once upon a time, there lived a fierce tiger. He ruled over the forest and as his carnivore nature hunted his prey. One day, he was feeling very hungry. He looked around for prey and soon enough found prey and hunted it.

 

As he started munching on his food he felt something stuck in his throat. He felt soring pain in his throat, he then soon realised that a bone was stuck in the throat as he was eating his prey. He tried very hard to get the bone removed from his throat but he was unable to do so.
Many days passed by, the tiger did not hunt nor could drink water because of the bone stuck in his throat. He was very weak and starving. The tiger thought to himself that he might die that day, and he collapsed on the ground. As he fell on the ground with his mouth open, a woodpecker saw it.