Ram Mandir is an under-construction Hindu temple in Ayodhya, Uttar Pradesh, India, at the site of Ram Janmabhoomi, which is believed to be the birthplace of the Lord Rama. The temple construction is being undertaken by Shri Ram Janmabhoomi Teerth Kshetra. The Bhoomi Pujan ceremony was performed in August 2020 by Prime Minister Narendra Modi.

The temple will have a will be 235 feet wide, 360 feet long, and 161 feet high and will be built in 10 acres and a prayer hall complex will be developed in 57 acres of land.

Inside the temple, the infant form of Lord Ram or Ram Lalla Virajman has presided. The modification and the demolition of the temple have stood as topics of controversy. In the 16th century, the Mughals constructed a mosque, the Babri Masjid which is believed to be the site of the Ram Janmabhoomi.

In 1992, the Babri Masjid was demolished during a political rally, triggering riots in India. Both Hindu and Muslim sides claimed ownership of the site, which led to an eventual lockdown of the area by the government.

On November 9, 2019, a Supreme Court bench led by Chief Justice Ranjan Gogoi unanimously ruled that the disputed land be given to the Ram Janmabhoomi Nyas for the construction of a temple, and the Muslim side be compensated with five acres of land at a prominent site in Ayodhya to build a mosque.